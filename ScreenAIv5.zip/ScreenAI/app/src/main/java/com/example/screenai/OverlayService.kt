package com.example.screenai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioManager
import android.media.ImageReader
import android.media.ToneGenerator
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.googlecode.tesseract.android.TessBaseAPI
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs

private class HttpErr(val code: Int, body: String) : Exception("HTTP $code: $body")

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var uiReady = false
    private var tearingDown = false

    // экран (быстрый режим)
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var w = 0
    private var h = 0

    // UI
    private lateinit var bubble: View
    private lateinit var panel: LinearLayout
    private lateinit var panelParams: WindowManager.LayoutParams
    private lateinit var input: EditText
    private lateinit var chatBox: LinearLayout
    private lateinit var chatScroll: ScrollView
    private lateinit var previewBox: LinearLayout
    private lateinit var previewImg: ImageView
    private lateinit var micBtn: TextView
    private lateinit var stopBtn: TextView
    private var attachedPath: String? = null

    // звук / голос
    private var recognizer: SpeechRecognizer? = null
    private var tone: ToneGenerator? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var soundOn = true
    private var ttsOn = false
    private var ttsRate = 1.0f
    private var ttsVol = 1.0f
    private var sttLang = "ru-RU"

    // настройки
    private var accent = 0xFF7C5CFF.toInt()
    private var visionOn = true

    // диалог
    private val history = mutableListOf<Pair<String, String>>()

    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val OVERLAY = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    override fun onBind(i: Intent?): IBinder? = null

    // ---------------------------------------------------------------- запуск
    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "shot" -> {
                if (uiReady) onShot(intent?.getStringExtra("path"))
                return START_NOT_STICKY
            }
            "shot_cancel" -> {
                if (uiReady) showUi()
                return START_NOT_STICKY
            }
        }
        val fast = intent?.getBooleanExtra("fast", false) ?: false
        val data = intent?.getParcelableExtra<Intent>("data")
        val withProjection = fast && data != null
        startAsForeground(withProjection)
        if (intent == null) { stopSelf(); return START_NOT_STICKY }

        if (uiReady) teardownUi()
        tearingDown = false
        readPrefs()
        tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70)
        if (tts == null) initTts()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (withProjection && data != null) setupCapture(intent.getIntExtra("code", 0), data)
        loadHistory()
        setupOverlay()
        uiReady = true
        return START_NOT_STICKY
    }

    private fun readPrefs() {
        val p = getSharedPreferences("s", 0)
        soundOn = p.getBoolean("sound", true)
        ttsOn = p.getBoolean("tts", false)
        ttsRate = p.getFloat("ttsRate", 1.0f)
        ttsVol = p.getFloat("ttsVol", 1.0f)
        accent = p.getInt("color", 0xFF7C5CFF.toInt())
        visionOn = p.getBoolean("vision", true)
        sttLang = p.getString("sttLang", "ru-RU") ?: "ru-RU"
    }

    private fun startAsForeground(withProjection: Boolean) {
        val ch = "screenai"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Screen AI", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("Screen AI работает")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            if (withProjection) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            startForeground(1, n, type)
        } else if (withProjection) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun teardownUi() {
        tearingDown = true
        runCatching { wm.removeView(bubble) }
        runCatching { wm.removeView(panel) }
        vDisplay?.release(); vDisplay = null
        reader?.close(); reader = null
        projection?.stop(); projection = null
        attachedPath = null
    }

    // ---------------------------------------------------------------- голос (TTS)
    private fun initTts() {
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { main.post { stopBtn.visibility = View.VISIBLE } }
                    override fun onDone(id: String?) { main.post { stopBtn.visibility = View.GONE } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { main.post { stopBtn.visibility = View.GONE } }
                    override fun onStop(id: String?, interrupted: Boolean) { main.post { stopBtn.visibility = View.GONE } }
                })
            }
        }
    }

    private fun speak(t: String) {
        if (!ttsOn || !ttsReady || t.isBlank()) return
        val cyr = t.any { it in 'а'..'я' || it in 'А'..'Я' }
        val vn = getSharedPreferences("s", 0).getString("voiceName", "") ?: ""
        val v = tts?.voices?.firstOrNull { it.name == vn }
        if (v != null && v.locale.language == (if (cyr) "ru" else "en")) {
            tts?.setVoice(v)
        } else {
            tts?.setLanguage(if (cyr) Locale("ru", "RU") else Locale.US)
        }
        tts?.setSpeechRate(ttsRate)
        val b = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, ttsVol) }
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, b, "ans")
    }

    private fun beep(type: Int) {
        if (soundOn) runCatching { tone?.startTone(type, 120) }
    }

    // ---------------------------------------------------------------- экран (быстрый режим)
    private fun setupCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { if (!tearingDown) stopSelf() }
        }, main)
        val dm = resources.displayMetrics
        w = dm.widthPixels
        h = dm.heightPixels
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        vDisplay = p.createVirtualDisplay(
            "screenai", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, main
        )
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        val bmp = ShotUtil.fromImage(img, w, h)
        img.close()
        return bmp
    }

    // ---------------------------------------------------------------- UI-помощники
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun roundedTop(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        val f = dp(r).toFloat()
        cornerRadii = floatArrayOf(f, f, f, f, 0f, 0f, 0f, 0f)
    }

    private fun ovalBg(color: Int) = GradientDrawable().apply {
        setShape(GradientDrawable.OVAL)
        setColor(color)
    }

    private fun label(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun circleBtn(t: String, bgColor: Int, onClick: () -> Unit) = TextView(this).apply {
        text = t
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        background = ovalBg(bgColor)
        setOnClickListener { onClick() }
    }

    private fun pill(t: String, bgColor: Int, onClick: () -> Unit) = TextView(this).apply {
        text = t
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(14), dp(10), dp(14), dp(10))
        background = rounded(bgColor, 18)
        setOnClickListener { onClick() }
    }

    private fun chip(t: String, prompt: String) = TextView(this).apply {
        text = t
        setTextColor(0xFFCFC8FF.toInt())
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = rounded(0xFF26234A.toInt(), 18)
        setOnClickListener { chipAction(prompt) }
    }

    private fun clean(s: String) = s
        .replace("**", "")
        .replace("```", "")
        .replace(Regex("(?m)^#{1,6}\\s*"), "")
        .trim()

    private fun scrollDown() {
        chatScroll.post { chatScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addMsg(role: String, text: String): TextView {
        val user = role == "user"
        val tv = TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextIsSelectable(true)
            setLineSpacing(0f, 1.1f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = rounded(if (user) accent else 0xFF1B1B28.toInt(), 14)
        }
        val lp = LinearLayout.LayoutParams(WRAP, WRAP).apply {
            topMargin = dp(6)
            gravity = if (user) Gravity.END else Gravity.START
            if (user) leftMargin = dp(40) else rightMargin = dp(40)
        }
        chatBox.addView(tv, lp)
        scrollDown()
        return tv
    }

    private fun greeting() = "Привет! Напиши или скажи вопрос. Кнопка «Поделиться экраном» отправит мне снимок экрана, но только после твоего подтверждения."

    // ---------------------------------------------------------------- построение интерфейса
    private fun setupOverlay() {
        val prefs = getSharedPreferences("s", 0)
        val size = dp(prefs.getInt("size", 56))
        val dm = resources.displayMetrics
        if (w == 0) { w = dm.widthPixels; h = dm.heightPixels }

        val avatarFile = File(filesDir, "avatar.png")
        bubble = if (avatarFile.exists()) {
            ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(BitmapFactory.decodeFile(avatarFile.absolutePath))
            }
        } else {
            TextView(this).apply {
                text = prefs.getString("btnText", "AI") ?: "AI"
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, size / dp(1) * 0.29f)
                typeface = Typeface.DEFAULT_BOLD
                background = ovalBg(accent)
            }
        }
        val bp = WindowManager.LayoutParams(
            size, size, OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = w - size - dp(12)
            y = dp(220)
        }
        wm.addView(bubble, bp)

        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = bp.x; sy = bp.y; tx = e.rawX; ty = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        bp.x = sx + dx
                        bp.y = sy + dy
                        wm.updateViewLayout(bubble, bp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        beep(ToneGenerator.TONE_PROP_PROMPT)
                        showPanel(panel.visibility != View.VISIBLE)
                    }
                }
            }
            true
        }

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedTop(0xF2141420.toInt(), 24)
            setPadding(dp(16), dp(14), dp(16), dp(16))
            visibility = View.GONE
        }

        // --- шапка
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(label("Screen AI", 17f, Color.WHITE, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        stopBtn = circleBtn("⏹", 0xFFEB5757.toInt()) { tts?.stop() }
        stopBtn.visibility = View.GONE
        header.addView(stopBtn, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(8) })
        val speaker = circleBtn(if (ttsOn) "🔊" else "🔇", 0xFF2A2A3A.toInt()) { }
        speaker.setOnClickListener {
            ttsOn = !ttsOn
            speaker.text = if (ttsOn) "🔊" else "🔇"
            if (!ttsOn) tts?.stop()
            getSharedPreferences("s", 0).edit().putBoolean("tts", ttsOn).apply()
        }
        header.addView(speaker, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(8) })
        header.addView(circleBtn("🗑", 0xFF2A2A3A.toInt()) { newChat() }, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(8) })
        header.addView(circleBtn("✕", 0xFF2A2A3A.toInt()) { stopSelf() }, LinearLayout.LayoutParams(dp(36), dp(36)))
        panel.addView(header)

        // --- чат
        chatBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        chatScroll = ScrollView(this)
        chatScroll.addView(chatBox)
        panel.addView(chatScroll, LinearLayout.LayoutParams(MATCH, (h * 0.30).toInt()).apply { topMargin = dp(10) })
        if (history.isEmpty()) {
            addMsg("assistant", greeting())
        } else {
            history.forEach { (r, c) -> addMsg(if (r == "user") "user" else "assistant", c) }
        }

        // --- предпросмотр снимка
        previewBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = rounded(0xFF1B1B28.toInt(), 14)
            visibility = View.GONE
        }
        previewImg = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            maxHeight = dp(150)
        }
        previewBox.addView(previewImg, LinearLayout.LayoutParams(MATCH, WRAP))
        val previewRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        previewRow.addView(
            pill("Отправить ИИ", accent) { submit(input.text.toString()) },
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(6) }
        )
        previewRow.addView(
            pill("↻ Заново", 0xFF2A2A3A.toInt()) { retake() },
            LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(6) }
        )
        previewRow.addView(pill("✕", 0xFF2A2A3A.toInt()) { discardShot() }, LinearLayout.LayoutParams(WRAP, WRAP))
        previewBox.addView(previewRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        panel.addView(previewBox, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        // --- «Поделиться экраном» и быстрые действия
        val share = TextView(this).apply {
            text = "📸 Поделиться экраном"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(12), 0, dp(12))
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(accent, 0xFF4F8CFF.toInt())
            ).apply { cornerRadius = dp(16).toFloat() }
            setOnClickListener { startShare(null) }
        }
        panel.addView(share, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })

        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            "✏️ Реши" to "Реши то, что на экране",
            "💡 Объясни" to "Объясни, что на экране",
            "🌐 Переведи" to "Переведи текст с экрана на русский",
            "📝 Кратко" to "Кратко перескажи текст с экрана",
            "💻 Код" to "Найди ошибки в коде на экране и предложи исправление"
        ).forEach { (t, p) ->
            chips.addView(chip(t, p), LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        }
        val chipScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chips)
        }
        panel.addView(chipScroll, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })

        // --- ввод
        input = EditText(this).apply {
            hint = "Спроси что-нибудь…"
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF77778A.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            background = rounded(0xFF22222F.toInt(), 22)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            maxLines = 3
        }
        val lang = circleBtn(if (sttLang.startsWith("en")) "EN" else "RU", 0xFF2A2A3A.toInt()) { }
        lang.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        lang.setOnClickListener {
            sttLang = if (sttLang.startsWith("ru")) "en-US" else "ru-RU"
            lang.text = if (sttLang.startsWith("en")) "EN" else "RU"
            getSharedPreferences("s", 0).edit().putString("sttLang", sttLang).apply()
        }
        micBtn = circleBtn("🎤", 0xFF2A2A3A.toInt()) { listen() }
        val send = circleBtn("➤", accent) { submit(input.text.toString()) }
        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        inputRow.addView(input, LinearLayout.LayoutParams(0, WRAP, 1f))
        inputRow.addView(lang, LinearLayout.LayoutParams(dp(40), dp(40)).apply { leftMargin = dp(6) })
        inputRow.addView(micBtn, LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(6) })
        inputRow.addView(send, LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(6) })
        panel.addView(inputRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })

        panelParams = WindowManager.LayoutParams(
            MATCH, WRAP, OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        wm.addView(panel, panelParams)
    }

    private fun showPanel(show: Boolean) {
        panelParams.flags = if (show) {
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        panel.visibility = if (show) View.VISIBLE else View.GONE
        wm.updateViewLayout(panel, panelParams)
    }

    private fun showUi() {
        showPanel(true)
        bubble.visibility = View.VISIBLE
    }

    private fun hideForCapture() {
        showPanel(false)
        bubble.visibility = View.INVISIBLE
    }

    // ---------------------------------------------------------------- диалог
    private fun newChat() {
        history.clear()
        File(filesDir, "history.json").delete()
        chatBox.removeAllViews()
        addMsg("assistant", greeting())
        discardShot()
    }

    private fun loadHistory() {
        history.clear()
        runCatching {
            val f = File(filesDir, "history.json")
            if (f.exists()) {
                val a = JSONArray(f.readText())
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    history.add(o.getString("r") to o.getString("c"))
                }
            }
        }
    }

    private fun saveHistory() {
        while (history.size > 60) history.removeAt(0)
        runCatching {
            val a = JSONArray()
            history.forEach { (r, c) -> a.put(JSONObject().put("r", r).put("c", c)) }
            File(filesDir, "history.json").writeText(a.toString())
        }
    }

    // ---------------------------------------------------------------- снимок экрана
    private fun chipAction(prompt: String) {
        if (projection != null) {
            askFast(prompt)
        } else {
            startShare(prompt)
        }
    }

    private fun startShare(prefill: String?) {
        if (prefill != null) input.setText(prefill)
        hideForCapture()
        if (projection != null) {
            main.postDelayed({
                val bmp = grab()
                showUi()
                if (bmp == null) {
                    addMsg("assistant", "Не удалось снять экран. Попробуй ещё раз.")
                } else {
                    val f = File(cacheDir, "shot.jpg")
                    ShotUtil.saveJpeg(bmp, f)
                    showPreview(f.absolutePath)
                }
            }, 450)
        } else {
            startActivity(
                Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    private fun onShot(path: String?) {
        showUi()
        if (path == null) {
            beep(ToneGenerator.TONE_PROP_NACK)
            addMsg("assistant", "Не удалось сделать снимок экрана. Нажми «Поделиться экраном» ещё раз.")
        } else {
            beep(ToneGenerator.TONE_PROP_ACK)
            showPreview(path)
        }
    }

    private fun showPreview(path: String) {
        attachedPath = path
        previewImg.setImageBitmap(BitmapFactory.decodeFile(path))
        previewBox.visibility = View.VISIBLE
        scrollDown()
    }

    private fun discardShot() {
        attachedPath?.let { runCatching { File(it).delete() } }
        attachedPath = null
        previewBox.visibility = View.GONE
        previewImg.setImageDrawable(null)
    }

    private fun retake() {
        discardShot()
        startShare(null)
    }

    // ---------------------------------------------------------------- отправка
    private fun submit(q: String) {
        val t = q.trim()
        when {
            attachedPath != null -> send(t)
            projection != null && t.isNotEmpty() -> askFast(t)
            t.isNotEmpty() -> send(t)
        }
    }

    /** Обычное сообщение или сообщение с подтверждённым снимком. */
    private fun send(q0: String) {
        val q = q0.ifBlank { "Что на экране? Объясни и помоги." }
        val path = attachedPath
        beep(ToneGenerator.TONE_PROP_BEEP)
        input.setText("")
        addMsg("user", if (path != null) "📸 $q" else q)
        val pending = addMsg("assistant", "Думаю…")
        previewBox.visibility = View.GONE
        attachedPath = null
        thread {
            try {
                var imageB64: String? = null
                var ocrText: String? = null
                var note = ""
                if (path != null) {
                    if (visionOn) {
                        imageB64 = Base64.encodeToString(File(path).readBytes(), Base64.NO_WRAP)
                    } else {
                        val bmp = BitmapFactory.decodeFile(path)
                        ocrText = ocr(bmp).ifBlank { "(текст не распознан)" }
                        note = "ⓘ Эта модель не читает картинки, поэтому отправил распознанный текст. Выбери 🆓 Gemini в настройках, чтобы ИИ видел сам снимок.\n\n"
                    }
                }
                val reply = callAI(q, ocrText, imageB64)
                main.post {
                    pending.text = note + reply
                    scrollDown()
                    beep(ToneGenerator.TONE_PROP_ACK)
                    speak(reply)
                }
            } catch (e: Exception) {
                main.post {
                    pending.text = friendly(e.message ?: "")
                    scrollDown()
                    beep(ToneGenerator.TONE_PROP_NACK)
                }
            } finally {
                if (path != null) runCatching { File(path).delete() }
            }
        }
    }

    /** Быстрый режим: экран читается сам, текст распознаётся на телефоне. */
    private fun askFast(q: String) {
        beep(ToneGenerator.TONE_PROP_BEEP)
        input.setText("")
        addMsg("user", q)
        val pending = addMsg("assistant", "Читаю экран…")
        reader?.acquireLatestImage()?.close()
        hideForCapture()
        main.postDelayed({
            val bmp = grab()
            showUi()
            if (bmp == null) {
                pending.text = "Не удалось снять экран"
            } else {
                thread {
                    try {
                        val text = ocr(bmp).ifBlank { "(текст не распознан)" }
                        main.post { pending.text = "Думаю…" }
                        val reply = callAI(q, text, null)
                        main.post {
                            pending.text = reply
                            scrollDown()
                            beep(ToneGenerator.TONE_PROP_ACK)
                            speak(reply)
                        }
                    } catch (e: Exception) {
                        main.post {
                            pending.text = friendly(e.message ?: "")
                            scrollDown()
                            beep(ToneGenerator.TONE_PROP_NACK)
                        }
                    }
                }
            }
        }, 400)
    }

    // ---------------------------------------------------------------- ИИ
    private fun callAI(q: String, screenText: String?, imageB64: String?): String {
        val prefs = getSharedPreferences("s", 0)
        val key = prefs.getString("key", "") ?: ""
        val model = (prefs.getString("model", "") ?: "").ifEmpty { "deepseek-flash" }
        val base = (prefs.getString("url", "") ?: "").trim().trimEnd('/').ifEmpty { "https://api.deepseek.com" }

        val system = "Ты — ScreenAI, умный ассистент на телефоне пользователя. " +
            "Отвечай на языке пользователя, по делу и без markdown-разметки. " +
            "Если приложен скриншот, опирайся на него и объясняй, что на нём. " +
            "Если дан текст с экрана (OCR), учти возможные ошибки распознавания. " +
            "В вопросах по программированию давай короткие рабочие примеры кода и объясняй причину ошибки. " +
            "Если данных не хватает, задай один уточняющий вопрос. Не выдумывай факты и честно говори, если не уверен."

        val messages = JSONArray().put(JSONObject().put("role", "system").put("content", system))
        history.takeLast(20).forEach { (r, c) ->
            messages.put(JSONObject().put("role", r).put("content", c))
        }
        val userContent: Any = when {
            imageB64 != null -> JSONArray()
                .put(JSONObject().put("type", "text").put("text", q))
                .put(JSONObject().put("type", "image_url")
                    .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$imageB64")))
            screenText != null -> "Текст с экрана (OCR):\n$screenText\n\nЗапрос: $q"
            else -> q
        }
        messages.put(JSONObject().put("role", "user").put("content", userContent))

        val body = JSONObject().put("model", model).put("messages", messages).toString()
        val raw = postWithRetry("$base/chat/completions", key, body)
        val reply = clean(raw).ifEmpty { "(пустой ответ)" }

        val histText = if (imageB64 != null || screenText != null) "[экран] $q" else q
        history.add("user" to histText)
        history.add("assistant" to reply)
        saveHistory()
        return reply
    }

    private fun postWithRetry(url: String, key: String, body: String): String {
        var last: Exception? = null
        for (attempt in 0 until 3) {
            try {
                return httpPost(url, key, body)
            } catch (e: HttpErr) {
                if (e.code != 429 && e.code < 500) throw e
                last = e
            } catch (e: java.net.UnknownHostException) {
                throw e
            } catch (e: java.io.IOException) {
                last = e
            }
            Thread.sleep(1500L * (attempt + 1))
        }
        throw last ?: Exception("Нет ответа от сервера")
    }

    private fun httpPost(url: String, key: String, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 120000
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Content-Type", "application/json")
        c.doOutput = true
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        if (code >= 400) {
            val err = c.errorStream?.bufferedReader()?.readText() ?: ""
            throw HttpErr(code, err)
        }
        val s = c.inputStream.bufferedReader().readText()
        return JSONObject(s).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").optString("content", "")
    }

    private fun friendly(msg: String): String = when {
        msg.contains("Insufficient Balance") -> "На аккаунте нет денег. Выбери бесплатного провайдера в настройках или пополни баланс."
        msg.contains("HTTP 401") || msg.contains("HTTP 403") -> "Ключ не подошёл (или провайдер недоступен в твоём регионе). Проверь ключ и адрес API."
        msg.contains("HTTP 404") -> "Модель или адрес API не найдены. Проверь поля «Адрес API» и «Модель»."
        msg.contains("HTTP 429") -> "Лимит запросов исчерпан. Подожди немного и повтори."
        msg.contains("HTTP 400") && visionOn -> "Провайдер отклонил запрос. Возможно, эта модель не принимает картинки: выключи «Модель понимает изображения» в настройках или выбери 🆓 Gemini."
        msg.contains("Unable to resolve host") -> "Нет интернета."
        else -> "Ошибка: $msg"
    }

    private fun ocr(bmp: Bitmap): String {
        val dir = File(filesDir, "tess")
        val td = File(dir, "tessdata").apply { mkdirs() }
        for (l in listOf("rus", "eng")) {
            val f = File(td, "$l.traineddata")
            if (!f.exists()) assets.open("tessdata/$l.traineddata").use { i -> f.outputStream().use { i.copyTo(it) } }
        }
        val api = TessBaseAPI()
        check(api.init(dir.absolutePath, "rus+eng")) { "Tesseract не запустился" }
        api.setImage(bmp)
        val t = api.getUTF8Text() ?: ""
        api.recycle()
        return t
    }

    // ---------------------------------------------------------------- распознавание речи
    private fun listen() {
        tts?.stop()
        recognizer?.destroy()
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = rec
        micBtn.background = ovalBg(0xFFEB5757.toInt())
        input.hint = "Слушаю…"
        beep(ToneGenerator.TONE_PROP_PROMPT)
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                micBtn.background = ovalBg(0xFF2A2A3A.toInt())
                input.hint = "Спроси что-нибудь…"
                beep(ToneGenerator.TONE_PROP_ACK)
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null) { input.setText(t); submit(t) }
            }
            override fun onError(e: Int) {
                micBtn.background = ovalBg(0xFF2A2A3A.toInt())
                input.hint = "Спроси что-нибудь…"
                beep(ToneGenerator.TONE_PROP_NACK)
                addMsg("assistant", "Голос не распознан (код $e). Попробуй ещё раз.")
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, sttLang)
        rec.startListening(i)
    }

    override fun onDestroy() {
        tearingDown = true
        uiReady = false
        tts?.stop()
        tts?.shutdown()
        tone?.release()
        recognizer?.destroy()
        runCatching { wm.removeView(bubble) }
        runCatching { wm.removeView(panel) }
        vDisplay?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
