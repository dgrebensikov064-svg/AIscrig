package com.example.screenai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.io.File

/** Делает ОДИН снимок экрана и сразу освобождает все ресурсы. */
class CaptureService : Service() {
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val ch = "screenai_capture"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Снимок экрана", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("Делаю снимок экрана")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
        startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { finish(null); return START_NOT_STICKY }

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {}
        }, main)
        val dm = resources.displayMetrics
        val w = dm.widthPixels
        val h = dm.heightPixels
        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        val vd = p.createVirtualDisplay(
            "shot", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, main
        )

        fun attempt(n: Int) {
            var path: String? = null
            try {
                val img = reader.acquireLatestImage()
                if (img != null) {
                    val bmp = ShotUtil.fromImage(img, w, h)
                    img.close()
                    val f = File(cacheDir, "shot.jpg")
                    ShotUtil.saveJpeg(bmp, f)
                    path = f.absolutePath
                }
            } catch (e: Exception) {
                path = null
            }
            if (path == null && n < 4) {
                main.postDelayed({ attempt(n + 1) }, 400)
            } else {
                vd.release()
                reader.close()
                p.stop()
                finish(path)
            }
        }
        main.postDelayed({ attempt(0) }, 900)
        return START_NOT_STICKY
    }

    private fun finish(path: String?) {
        startService(
            Intent(this, OverlayService::class.java)
                .setAction("shot")
                .putExtra("path", path)
        )
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
}
